import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.CardLayout;
import java.util.List;


public class Patient extends JFrame {
	private JTable table;
	private JPanel contentPane;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Patient frame = new Patient();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/**
	 * Create the frame.
	 * 
	 */
	public Patient()  {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 512, 357);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 206, 209));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		
		JButton btnBack = new JButton("Back");  //Back button 
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cmd = e.getActionCommand();
				if(cmd.equals("Back")) { 
					dispose();
					new Patient();
					AmbulanceApp Ad = new AmbulanceApp(); 
					Ad.setVisible(true);
				}
			}
		});
		
		JButton btnAddNew = new JButton("Add New");         //Add new button 
		btnAddNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cmd = e.getActionCommand(); 
				if(cmd.equals("Add New")) { 
					dispose(); 
					AddEdit addNew = new AddEdit();
					addNew.setVisible(true);		
			}
	}	
				
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 466, Short.MAX_VALUE)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(btnBack, GroupLayout.PREFERRED_SIZE, 95, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 271, Short.MAX_VALUE)
							.addComponent(btnAddNew, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(40)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 205, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnBack, GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE)
						.addComponent(btnAddNew, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE))
					.addGap(11))
		);
		
		
		try {
			 
            BufferedReader br = new BufferedReader(new FileReader(new File("patients.csv")));
            
            List<String[]> elements = new ArrayList<String[]>();
            String line = null;
            while((line = br.readLine())!=null) {
                 String[] splitted = line.split(",");
                elements.add(splitted);
        
                   

            }	
            br.close();
		
            table = new JTable();
            String[] columNames = new String[] {
                    "ID", "Location", "Status", "Ambulance"
                    
            };
                   
         
            Object[][] content = new Object[elements.size()][5];
            
            
            for(int i=1; i<elements.size(); i++) {
            	
            	
                content[i - 1][0] = elements.get(i)[0];
                content[i- 1][1] = "("+ elements.get(i)[1] + "," + elements.get(i)[2] + ")";
                content[i-1][2] = elements.get(i)[3];
                if (elements.get(i).length == 5) { 
                	 content[i-1][3] = elements.get(i)[4]; 
                }               
               
            } 
	            
	            table.addMouseListener(new MouseAdapter() {
	            public void mouseClicked(MouseEvent e) {
                  if (e.getClickCount() == 1) {
                    int row = table.getSelectedRow();
              //      String id = (String) table.getModel().getValueAt(row, 0);
              //      String[] location = ((String) table.getModel().getValueAt(row, 1)).split(", ");
              //      String xLocation = location[0].replace("(", "");
               //     String yLocation = location[1].replace(")", "");
                //    String status = (String) table.getModel().getValueAt(row, 2);
                 //   String ambulance = (String) table.getModel().getValueAt(row, 3);
                 //   System.out.println(row);
                     AddEdit An = new AddEdit(); 
                    An.setVisible(true);
                    dispose();
                    }
                 }
	          });
		
		table.setModel(new DefaultTableModel(content,columNames)); 
		scrollPane.setViewportView(table);
		contentPane.setLayout(gl_contentPane);
		table.setVisible(true);
	
 
        } catch (Exception ex) {
            ex.printStackTrace();
        }
	}
}
