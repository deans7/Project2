import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.UIManager;
import java.awt.Color;
import javax.swing.JToggleButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Button;

public class AmbulanceApp extends JFrame  {

	protected static final String ActionEvent = null;
	private JPanel contentPane;
	private JFrame frame, frame2; 
	


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try{
					AmbulanceApp frame = new AmbulanceApp(); 
					frame.setVisible(true);
				}catch(Exception e){
					e.printStackTrace();
				}
			}	
		}
	);
}

	
	/**
	 * Create the frame.
	 */
	public AmbulanceApp() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 512, 357);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 206, 209));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
				
		//Create buttons and attributes 
		JButton btnPatients = new JButton("Patients");
		btnPatients.setBounds(84, 39, 362, 66);
		btnPatients.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cmd = e.getActionCommand();
				if(cmd.equals("Patients")){
					dispose();
					new AmbulanceApp();
					Patient Pt = new Patient();
					Pt.setVisible(true);
				}
			}
		});
		
		
		btnPatients.setOpaque(true);
		btnPatients.setForeground(Color.WHITE);
		btnPatients.setBackground(Color.BLUE);
		
		
		JButton btnAmbulance = new JButton("Ambulance");
		btnAmbulance.setBounds(84, 133, 362, 69);
		/*
		btnAmbulance.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				String cmd = e.getActionCommand(); 
				if(cmd.equals("Ambulance")) { 
					dispose();
					new AmbulanceAppTracker(); 
					AmbulanceClass Ac = new AmbulanceClass(); 
					Ac.setVisible(true);
				}
				
			}
		});
		*/
		
	
		btnAmbulance.setForeground(Color.WHITE);
		btnAmbulance.setBackground(Color.BLUE);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setBounds(84, 220, 362, 70);
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cmd = e.getActionCommand(); 
				if(cmd.equals("Exit")) {
					dispose();
				}
			}
		});
		
		btnExit.setForeground(Color.WHITE);
		btnExit.setBackground(Color.BLUE);
		contentPane.setLayout(null);
		
		
		JLabel lblAmbulanceTrackingSystem = new JLabel("Ambulance Tracking System");   //Title of program 
		lblAmbulanceTrackingSystem.setBounds(84, 5, 342, 28);
		lblAmbulanceTrackingSystem.setFont(new Font("Arial", Font.BOLD, 25));   //Set Font, size and make BOLD 
		lblAmbulanceTrackingSystem.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblAmbulanceTrackingSystem);
		contentPane.add(btnExit);
		contentPane.add(btnAmbulance);
		contentPane.add(btnPatients);
	}
}