import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
//import com.jgoodies.forms.layout.FormLayout;
//import com.jgoodies.forms.layout.ColumnSpec;
//import com.jgoodies.forms.layout.RowSpec;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JLabel;

public class AddEdit extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JComboBox<String> comboBox_1 = new JComboBox<String>();
	private JComboBox<String> comboBox = new JComboBox<String>();
	private String status; 
	private String id; 
	private boolean enable; 
	private String xLocation;
	private String yLocation; 

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddEdit frame = new AddEdit();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	//public AddEdit(String id, String xLocation, String yLocation, String status, String ambulance, Boolean enable) {
	//	super("Ambulance app");
//	}
	
	public AddEdit() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Cancel");
		btnNewButton.setBounds(0, 214, 117, 36);
		contentPane.add(btnNewButton);
		
		
		
	
		JButton btnNewButton_1 = new JButton("Save");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cmd = e.getActionCommand();
				if(cmd.equals("Save")) {  
					dispose();
				}
			}
			
		});
		btnNewButton_1.setBounds(316, 214, 97, 36);
		contentPane.add(btnNewButton_1);
		
				
	
		
		
		
		
		//JComboBox<String> comboBox = new JComboBox<String>();
		comboBox.setBounds(149, 146, 264, 31);
		contentPane.add(comboBox);
		
	 //	JComboBox<String> comboBox_1 = new JComboBox<String>();
		comboBox_1.setBounds(152, 86, 261, 31);
	//	comboBox_1.addItem("");
	//	comboBox_1.addItem("Pending");
	//	comboBox_1.addItem("Assigned");
	//	comboBox_1.addItem("Transporting");
	//	comboBox_1.addItem("comboBox_1.addItem");
	//	comboBox_1.setSelectedItem(status);
		contentPane.add(comboBox_1);
		
		textField = new JTextField(); //location xtextfield 
		textField.setBounds(149, 55, 86, 20);
	    textField.setText(xLocation);   
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField(); // location ytextfield
		textField_1.setBounds(286, 55, 86, 20);
		textField.setText(yLocation);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		
		JLabel lblNewLabel = new JLabel("ID:");
		lblNewLabel.setBounds(10, 16, 46, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Location");
		lblNewLabel_1.setBounds(10, 55, 72, 17);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Status");
		lblNewLabel_2.setBounds(10, 94, 46, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Ambulance");
		lblNewLabel_3.setBounds(10, 148, 72, 20);
		contentPane.add(lblNewLabel_3);
		
		textField_2 = new JTextField(); //Textfield for ID 	
		textField_2.setBounds(151, 16, 221, 17);
//		textField_2.setText(id);
//		textField_2.setEnabled(enable);
		contentPane.add(textField_2);
		textField_2.setEditable(false);
		textField_2.setColumns(10);
		
		
		
		
	}
}
